// chart-script.js

document.addEventListener('DOMContentLoaded', () => {
    // Check if data is injected in a global variable "window.probabilityBreakdown"
    if (window.probabilityBreakdown) {
        const ctx = document.getElementById('probabilityPieChart').getContext('2d');

        const data = {
            labels: Object.keys(window.probabilityBreakdown),
            datasets: [{
                data: Object.values(window.probabilityBreakdown),
                backgroundColor: [
                    'rgba(239, 68, 68, 0.7)',  // red (FAKE)
                    'rgba(37, 99, 235, 0.7)'   // blue (REAL)
                ],
                borderColor: [
                    'rgba(220, 38, 38, 1)',
                    'rgba(29, 78, 216, 1)'
                ],
                borderWidth: 2,
                hoverOffset: 30
            }]
        };

        const options = {
            responsive: true,
            animation: {
                animateRotate: true,
                duration: 1200
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        font: {
                            size: 16,
                            weight: 'bold'
                        },
                        color: '#1e293b' // slate-800
                    }
                },
                tooltip: {
                    enabled: true,
                    callbacks: {
                        label: ctx => `${ctx.label}: ${ctx.parsed}%`
                    }
                }
            }
        };

        new Chart(ctx, {
            type: 'pie',
            data: data,
            options: options
        });
    }
});
